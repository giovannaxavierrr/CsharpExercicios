using static System.Console;
 
public class Horario
{
    // Valor inicial é 00:00:00
    public int Hora = 0;
    public int Minuto = 0;
    public int Segundo = 0;
 
    public void Adicionar(int segundos, int minutos, int horas)
    {
        Segundo += segundos;
        if (Segundo > 59)
        {
            minutos += Segundo / 60;
            Segundo = Segundo % 60;
        }
        Minuto += minutos;
        if (Minuto > 59)
        {
            horas += Minuto / 60;
            Minuto = Minuto % 60;
        }    
        Hora += horas;
        if (Hora > 23)
        {
                Hora = Hora % 24;
        }
    }
 
    public void Adicionar(int segundos, int minutos)
    {
        Adicionar(segundos, minutos, 0);
    }
    public void Adicionar(int segundos)
    {
        Adicionar(segundos, 0, 0);
    }
    public void Adicionar(Horario horario)
    {
        Adicionar(horario.Hora, horario.Minuto, horario.Segundo);
    }
    public string Formatar()
    {
        return $"{Hora}:{Minuto}:{Segundo}";
    }
}