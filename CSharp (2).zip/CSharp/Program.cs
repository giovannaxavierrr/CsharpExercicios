﻿/*int numero1 = 0;
int numero2 = 0;
String operacao = "";

Console.WriteLine("Bem vinda a calculadora em C#!");

/*
if (args.Length < 2) {
    Console.WriteLine("Informe dois numeros e a operação desejada para calcular!!");
    return;
}

if (!int.TryParse(args[0], out numero1)) {
    Console.WriteLine("Valor 1 inválido");
}

if (!int.TryParse(args[1], out numero1)) {
    Console.WriteLine("Valor 1 inválido");
}
///***

Console.Write("Digite o número 1: ");
numero1 = int.Parse(Console.ReadLine());
Console.Write("Digite o número 2: ");
numero2 = int.Parse(Console.ReadLine());
Console.Write("Digite a operação: ");
operacao = Console.ReadLine();

if (operacao == "+") {
    Console.WriteLine(numero1 + numero2);
} else if (operacao == "-") {
    Console.WriteLine(numero1 - numero2);
} else if (operacao == "*") {
    Console.WriteLine(numero1 * numero2);
} else if (operacao == "/") {
    Console.WriteLine(numero1 / numero2);
} else {
    Console.WriteLine("Operação inválida, escolha entre + - * ou /");
}


using static System.Console;

double somar(double num1, double num2) {
    double soma = num1 + num2;
    return soma;
}

void mostrarMensagem(String texto) {
    WriteLine(texto);
}

mostrarMensagem("Hello World!");

double valor1 = somar(5, 10);
WriteLine(valor1);

double valor2 = somar(1500, 8888);
WriteLine(valor2);
*/

Console.WriteLine("Digite os codigos binarios: ");

String entrada = Console.ReadLine(); //vai pegar o que o usuario digitou

String[] partes = entrada.Split(','); //usuario separa os codigos com a virgula, e a cada virgula separamos em valores diferentes de array

byte[] dados = new byte[partes.Length]; //cria um array de dados do tamanho da quantidade de valores que o usuario digitou

for (int i = 0; i < partes.Length; i++) { //vai percorrer a array inteira
    
    String valor = partes[i].Trim(); //.Trim() tira os espaços que o usuário digitou

    dados[i] = Convert.ToByte(valor, 2); //converte o valor binário (base 2) para byte (base 10)

}

byte[] resultado = compact(dados); //função compact() declarada na linha 86

Console.WriteLine("Resultado compactado:");

foreach (var b in resultado) { //percorre cada byte do resultado compactado
    Console.WriteLine(Convert.ToString(b, 2).PadLeft(8, '0')); //converte o byte de volta pra binário (string) | O padleft garante que tenha 8 bits, com zeros a esquerda
}

byte[] compact(byte[] originalData) { //função que chamamos para pegar os dados e reduzi-los pela metade, juntando ele em pares (compactando)

    byte[] compacted = new byte[originalData.Length / 2]; //cria um array com metade do tamanho de um byte

    int j = 0;

    for(int i = 0; i < originalData.Length; i += 2) { //anda de dois em dois pq vamos usar pares
        
        byte primeiro = (byte)(originalData[i] >> 4); //pega o primeiro byte e desloca 4 bits pra direita, ficando só com os 4 bits mais significativos

        byte segundo = (byte)(originalData[i+1] >> 4); //faz a mesma coisa que o primeiro, mas com o segundo byte do par

        byte combinados = (byte)((primeiro << 4) | segundo); //junta os dois valores, variavel primeiro ocupa os 4 bits da esquerda, e a variavel segundo ocupa os 4 bits da direita 

        compacted[j] = combinados; //armazena no novo array

        j++;

    }
    
    return compacted;

}

byte[] decompact(byte[] compactedData) { //função que desfaz a compactação

    byte[] original = new byte[compactedData.Length * 2]; //cria um array com o dobro do tamanho, voltando ao original

    int j = 0;

    for (int i = 0; i < compactedData.Length; i++) { //passa por cada byte compactado

        byte primeiro = (byte)(compactedData[i] >> 4); //pega os 4 bits da esquerda

        byte segundo = (byte)(compactedData[i] & 0b00001111); //0b00001111 significa que o numero está em binário de base 2, então vai pegar os 4 bits da direita

        original[j] = (byte)(primeiro << 4); //volta os bits da variavel primeiro para posição original
        original[j + 1] = (byte)(segundo << 4); //volta os bits do segundo para posição original

        j += 2; //avança duas posições, porque estamos recriando pares

    }

    return original;

}