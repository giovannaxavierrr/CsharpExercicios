﻿// O jardim começa com uma casa em qualquer posição. Uma casa tem uma pequena probabilidade de criar outra casa próxima.

using System.Drawing;
using TheGarden;
var garden = new Garden();
garden.ChangeColor(Color.Green); //o fundo vai ser verde (jardim)

garden.Add("house", Color.Pink); //as casas vão ser rosa
garden.AddRandom("house", Color.Pink, 1); // vai colocar uma casinha num lugar aleatorio do mapa
garden.Run();
 
public class House
{

    public int Timer { get; set; } = 30; //primeiro valor do Timer é de 30 frames (3seg)

    public void Act(Gardenkeeper keeper) 
    {
        // espera 30 frames (3 segundos)
        Timer--; //vai diminuindo o tempo
        if (Timer > 0) //quando zerar o timer
        {
            return;
        }

        Timer = Random.Shared.Next(20,50); // novo valor do timer vai ser aleatorio, entre 2 e 5 seg)

        int dx = Random.Shared.Next(-30, 30); //para que a casa a ser criada surja num lugar aleatorio | x = horizontal
        int dy = Random.Shared.Next(-30, 30); //para que a casa a ser criada surja num lugar aleatorio | y = vertical

        if (Random.Shared.Next(100) < 2) //uma chance pequena
        {
            keeper.ReproduceOnNeighborhood(1); //vai gerar uma casinha perto da ultima criada
        }
        else //se não cair nessa probabilidade pequena acima
        {
            keeper.CreateEntityOnNeighborhood("house", dx, dy); //vai criar num lugar aleatorio poix o valor de x e y é aleatorio com as variaveis que criei em cima
        }
        
    }
}


/*
using System.Drawing;
using TheGarden;
var garden = new Garden();
garden.AddRandom("man", Color.Blue, 20);
garden.AddRandom("woman", Color.Pink, 20);
garden.Run();
public class Man
{
    public int Age { get; set; }
    public void Act(Gardenkeeper keeper)
    {
        Age++;
        keeper.Move(
           Random.Shared.Next(-1, 2),
           Random.Shared.Next(-1, 2)
        );
        var lucky = Random.Shared.Next(100);
        if (Age > 600 && lucky < 10)
            keeper.KillMe();
        }
}
 
public class Woman
{
    public int WaitingABaby { get; set; }
    public int Age { get; set; }
    public void Act(Gardenkeeper keeper)
    {
        Age++;
        keeper.Move(
            Random.Shared.Next(-1, 2),
            Random.Shared.Next(-1, 2)
        );
        if (WaitingABaby > 0)
            WaitingABaby++;
        if (WaitingABaby > 8)
        {
            WaitingABaby = 0;
            keeper.ChangeColor(Color.Pink);
            if (Random.Shared.Next(100) < 50)
            {
                keeper.CreateEntityOnNeighborhood("man", 1);
            }
            else
            {
                keeper.CreateEntityOnNeighborhood("woman", 1);
            }
        }
 
        var lucky = Random.Shared.Next(100);
        if (Age > 600 && lucky < 10)
            keeper.KillMe();
 
        if (Age < 180 || Age > 450)
            return;
 
        if (WaitingABaby > 0)
            return;
        if (keeper.CountNeighborhood("man", 2) < 1)
            return;
       
        WaitingABaby++;
        keeper.ChangeColor(Color.DeepPink);
    }
}
 
using System.Drawing; // Para cores
using TheGarden; // Para usar o TheGarden
var garden = new Garden();
// Colocando 1 Drunk Person na posição (40, 40)
garden.Add("drunkperson", Color.Beige, 40, 40);
garden.Run();
public class DrunkPerson
{
 
   public void Act(Gardenkeeper keeper)
   {
        // Pede ao jardineiro que o mova aleatóriamente por ai
        keeper.Move(
            Random.Shared.Next(-1, 2),
            Random.Shared.Next(-1, 2)
        );
    }
}
*/