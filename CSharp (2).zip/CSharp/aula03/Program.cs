﻿using System;

/*public class Aluno {

    string nome;
    int idade;

    public void AdicionarIdade() {



    }
}

//Heap
Aluno aluno = new Aluno() //vai pegar as propriedades string, int, etc

//Stack

/*
--------------
AdicionarIdade
--------------
string nome
--------------
int idade
--------------
*/
//cria uma pilha de frações, e o ponteiro vai apontar pra qual usar

/*using static System.Console;

//tipos por valor, faz uma copia do valor que consta na variavel
int idade = 16;
int idade2 = idade;

idade2++;

WriteLine(idade);
WriteLine(idade2);

//tipos por referencia, utiliza um ponteiro que indica onde estão os valores
Aluno aluno = new Aluno();
aluno.Idade = 16;

//Aluno aluno2 = aluno; //referencia por ponteiro
Aluno aluno2 = new Aluno();
aluno2.Idade = aluno.Idade;
aluno2.Idade++;
WriteLine(aluno.Idade);
WriteLine(aluno2.Idade);

//chamar a função
int numero = 47;
AlterarNumero(numero);
WriteLine("Valor de numero: "+numero);

Aluno aluno3 = new Aluno();
aluno3.Nome = "Marcelo";
AlterarNome(aluno3);
WriteLine(aluno3.Nome);

void AlterarNome(Aluno aluno3)
{
    aluno3.Nome = "Will";
}

void AlterarNumero(int valor)
{
    valor = valor + 1;
    WriteLine("Valor da Função: "+valor);
}

//classe
public class Aluno 
{
    public string Nome { get; set; }
    public int Idade { get; set; }
}
*/

/*List<int> lista = new List<int>();
lista.Add(4);
lista.Add(10);
lista.Add(47);

for (int i = 0; i < lista.Count; i++)
{
    Console.WriteLine(lista[i]);
}*/

ListaInteiros lista = new ListaInteiros();
lista.Add(123);
lista.Add(22);
lista.Add(50);

Console.WriteLine(lista.Get(0));
Console.WriteLine(lista.Get(1));
Console.WriteLine(lista.Get(2));

lista.Set(0, 95);

Console.WriteLine(lista.Get(0));
Console.WriteLine(lista.Get(1));
Console.WriteLine(lista.Get(2));

Console.WriteLine("Nr de elementos: "+lista.Contador);

public class ListaInteiros
{
    private int posicao = 0;
    private int[] vetor = new int[10];

    public void Add(int value)
    {
        //verificar o tamanho do vetor
        int len = vetor.Length;

        //vetor estouraria, vamos aumentar o tamanho
        if(posicao == len)
        {
            //criar um vetor maior pra não dar stack overflow
            int[] newVetor = new int[2 * len];

            //copia os dados do vetor antigo para o novo vetor
            for(int i = 0; i < posicao; i++)
            {
                newVetor[i] = vetor[i];
            }

            //jogamos a referencia antiga do vetor fora e o ponteiro 'vetor' irá apontar para o novo vetor
            vetor = newVetor;
        }

        vetor[posicao] = value;
        posicao++;
    }

    public int Contador => posicao;

    public void Set(int i, int value)
    {
        this.vetor[i] = value;
    }

    public int Get(int i)
    {
        return this.vetor[i];
    }

}