public class Cliente {

    public string Nome;
    public string Endereco;
    public string Cpf;

    public void AtualizarEndereco(string novoEndereco) {
        Endereco = novoEndereco;
    }
}