﻿using System;

Horario h1 = new Horario();
Horario h2 = new Horario();
h1.Adicionar(20, 40, 30); //h1 = 20:40:30
h2.Adicionar(20, 30); //h2 = 00:20:30
h1.Adicionar(h2); //h1 = 21:01:00, h2 inalterado
h2.Adicionar(h1); //h2 = 00:20:30 + 21:01:00 = 21:21:30, h1 inalterado
Console.WriteLine(h2.Formatar()); //21:21:30

/*
Console.WriteLine("Hello World!");

Cliente cliente1 = new Cliente();
cliente1.Nome = "Giovanna";
cliente1.Endereco = "Rua dos Professores";
cliente1.Cpf = "123123123-10";

Cliente cliente2 = new Cliente();
cliente2.Nome = "Joao";
cliente2.Endereco = "Rua dos Professores";
cliente2.Cpf = "123123123-11";

cliente2.AtualizarEndereco("dos Professores");

Console.WriteLine(cliente1.Nome);
Console.WriteLine(cliente2.Cpf);
*/